// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _ASSETS_SPRITES_PLAYER_DOWN_H_
#define _ASSETS_SPRITES_PLAYER_DOWN_H_

#include <types.h>
#define SPRITE_PLAYER_DOWN_0_W 5
#define SPRITE_PLAYER_DOWN_0_H 11
extern const u8 sprite_player_down_0[5 * 11];
#define SPRITE_PLAYER_DOWN_1_W 5
#define SPRITE_PLAYER_DOWN_1_H 11
extern const u8 sprite_player_down_1[5 * 11];
#define SPRITE_PLAYER_DOWN_2_W 5
#define SPRITE_PLAYER_DOWN_2_H 11
extern const u8 sprite_player_down_2[5 * 11];
#define SPRITE_PLAYER_DOWN_3_W 5
#define SPRITE_PLAYER_DOWN_3_H 11
extern const u8 sprite_player_down_3[5 * 11];
#define SPRITE_PLAYER_DOWN_4_W 5
#define SPRITE_PLAYER_DOWN_4_H 11
extern const u8 sprite_player_down_4[5 * 11];
#define SPRITE_PLAYER_DOWN_5_W 5
#define SPRITE_PLAYER_DOWN_5_H 11
extern const u8 sprite_player_down_5[5 * 11];
#define SPRITE_PLAYER_DOWN_6_W 5
#define SPRITE_PLAYER_DOWN_6_H 11
extern const u8 sprite_player_down_6[5 * 11];
#define SPRITE_PLAYER_DOWN_7_W 5
#define SPRITE_PLAYER_DOWN_7_H 11
extern const u8 sprite_player_down_7[5 * 11];

#endif
