// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _ASSETS_SPRITES_PLAYER_UP_H_
#define _ASSETS_SPRITES_PLAYER_UP_H_

#include <types.h>
extern const u8 sprite_palette[16];

#define SPRITE_PLAYER_UP_0_W 5
#define SPRITE_PLAYER_UP_0_H 16
extern const u8 sprite_player_up_0[5 * 16];
#define SPRITE_PLAYER_UP_1_W 5
#define SPRITE_PLAYER_UP_1_H 16
extern const u8 sprite_player_up_1[5 * 16];

#endif
