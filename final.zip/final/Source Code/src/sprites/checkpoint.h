// Data created with Img2CPC - (c) Retroworks - 2007-2015
#ifndef _ASSETS_SPRITES_CHECKPOINT_H_
#define _ASSETS_SPRITES_CHECKPOINT_H_

#include <types.h>
#define SPRITE_CHECKPOINT_W 3
#define SPRITE_CHECKPOINT_H 14
extern const u8 sprite_checkpoint[3 * 14];

#endif
