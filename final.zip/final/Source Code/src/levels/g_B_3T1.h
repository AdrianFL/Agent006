//-----------------------------LICENSE NOTICE-----------------------------------------------------
//  This file is part of Amstrad CPC videogame "Agent 006"
//  Copyright (C) 2017 APLSoft / Adrian Frances Lillo / Pablo Lopez Iborra / Luis Gonzalez Aracil
//  Copyright (C) 2015-2016 ronaldo / Fremos / Cheesetea / ByteRealms (@FranGallegoBR)
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.
//-----------------------------LICENSE NOTICE-----------------------------------------------------


// File assets/maps/g_B_3T1.tmx converted to csv using cpct_tmx2csv [20171027 02:51:47 CEST]
//   * Width:  10 columns (5 bytes, 4 bits per column)
//   * Height: 25 rows
//   * Bytes:  125 bytes (5 x 25)
//
#include <types.h>

// Generated CSV tilemap from assets/maps/g_B_3T1.tmx
//   125 bytes (5 x 25)
//   10*25 items (4 bits per item)
//
#define g_B_3T1_W  5
#define g_B_3T1_H  25
extern const u8 g_B_3T1[5*25];
